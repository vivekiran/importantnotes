<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It is a breeze. Simply tell Lumen the URIs it should respond to
| and give it the Closure to call when that URI is requested.
|
*/

$api = app('Dingo\Api\Routing\Router');

$api->version('v1', function ($api) use ($app){

	$api->get('test', function () use ($api,$app) {
	    return $api->isCreated();
	});
});




$app->post('auth/login', 'Auth\AuthController@postLogin');

$app->group(['prefix' => 'projects', 'middleware' => 'auth:api'], function($app) {
    $app->post('/', 'ProjectsController@store');
    $app->put('/{projectId}', 'ProjectsController@update');
    $app->delete('/{projectId}', 'ProjectsController@destroy');

    $app->get('/test', function () use ($app) {
	    return $app->version();
	});
});

$app->group(['prefix' => 'projects'], function ($app)
{
    $app->get('/', 'ProjectsController@index');
    $app->get('/{projectId}', 'ProjectsController@show');


});